<?php
$plugin_path = plugins_url('theme-core');
return array(
    'title' => __('Theme Options', 'theme-core'),
    'logo' => $plugin_path.'/admin/logo.png',
    'menus' => array(
        array(
            'title' => __('General Settings', 'theme-core'),
            'name' => 'menu_1',
            'icon' => 'font-awesome:fa-magic',
            'menus' => array(
                array(
                    'title' => __('Header', 'theme-core'),
                    'name' => 'header',
                    'icon' => 'font-awesome:fa-th-large',
                    'controls' => array(
                        //Logo Image Section
                        array(
                            'type' => 'section',
                            'title' => __('Logo Image', 'theme-core'),
                            'name' => 'image_logo_section',
                            'description' => __('Upload or select logo for header.', 'theme-core'),
                            'fields' => array(
                                array(
                                    'type' => 'upload',
                                    'name' => 'image_logo',
                                    'label' => __('Image Logo', 'theme-core'),
                                    'description' => __('Upload or choose custom logo', 'theme-core'),
                                ),
                            ),
                        ),
                        // Other Details Section
                        array(
                            'type' => 'section',
                            'title' => __('Other Details', 'theme-core'),
                            'name' => 'other_section',
                            'description' => __('Other Details', 'theme-core'),
                            'fields' => array(
                                // Enable Hamburg Menu
                                array(
                                    'type' => 'toggle',
                                    'name' => 'enable_hamburg_menu',
                                    'label' => __('Enable Hamburg Menu', 'theme-core'),
                                    'description' => __('You can enable hamburg menu for site.', 'theme-core'),
                                    'default' => '0',
                                ),
                                // Enable Dark Layout
                                array(
                                    'type' => 'toggle',
                                    'name' => 'enable_dark',
                                    'label' => __('Enable Dark Layout', 'theme-core'),
                                    'description' => __('You can enable Dark layout for site.', 'theme-core'),
                                    'default' => '0',
                                ),
                                // Disable Pre Loader
                                array(
                                    'type' => 'toggle',
                                    'name' => 'disable_pre_loader',
                                    'label' => __('Disable Pre Loader', 'theme-core'),
                                    'description' => __('You can disable pre loader for site.', 'theme-core'),
                                    'default' => '0',
                                ),
                                // Pre Loader Text
                                array(
                                    'type' => 'textbox',
                                    'name' => 'pre_loader_text',
                                    'label' => __('Pre Loader Text', 'theme-core'),
                                    'description' => __('Enter pre loader text here.', 'theme-core'),
                                    'default' => 'Please Wait...',
                                ),
                                // Pre Loader Logo
                                array(
                                    'type' => 'upload',
                                    'name' => 'pre_loader_logo',
                                    'label' => __('Pre Loader Logo', 'theme-core'),
                                    'description' => __('Upload logo for pre loader.', 'theme-core'),
                                ),
                                // Map API
                                array(
                                    'type' => 'textbox',
                                    'name' => 'map_api',
                                    'label' => __('Google Map API', 'theme-core'),
                                    'description' => __('Input google map API key here.', 'theme-core')
                                ),
                                // Custom CSS
                                array(
                                    'type' => 'codeeditor',
                                    'name' => 'custom_css',
                                    'label' => __('Custom CSS', 'theme-core'),
                                    'description' => __('Write your custom css here.', 'theme-core'),
                                    'theme' => 'github',
                                    'mode' => 'css',
                                ),
                                // Custom JS
                                array(
                                    'type' => 'codeeditor',
                                    'name' => 'custom_js',
                                    'label' => __('Custom JS', 'theme-core'),
                                    'description' => __('Write your custom js here.', 'theme-core'),
                                    'theme' => 'twilight',
                                    'mode' => 'javascript',
                                ),
                                // Footer Copyright
                                array(
                                    'type' => 'textbox',
                                    'name' => 'footer_copyright',
                                    'label' => __('Copyright Text', 'theme-core'),
                                    'description' => __('Only alphabets and numbers allowed here.', 'theme-core'),
                                ),
                            ),
                        ),
                    ),
                ),
            ),
        ),
        // Styling Options
        array(
            'title' => __('Styling Options', 'theme-core'),
            'name' => 'styling_options',
            'icon' => 'font-awesome:fa-gift',
            'controls' => array(
                // Heading Section
                array(
                    'type' => 'section',
                    'title' => __('Headings', 'theme-core'),
                    'fields' => array(
                        // Heading H1
                        array(
                            'type' => 'color',
                            'name' => 'heading_h1',
                            'label' => __('Heading H1', 'theme-core'),
                            'description' => __('Color Picker, you can set heading color.', 'theme-core'),
                        ),
                        // Heading H2
                        array(
                            'type' => 'color',
                            'name' => 'heading_h2',
                            'label' => __('Heading H2', 'theme-core'),
                            'description' => __('Color Picker, you can set heading color.', 'theme-core'),
                        ),
                        // Heading H3
                        array(
                            'type' => 'color',
                            'name' => 'heading_h3',
                            'label' => __('Heading H3', 'theme-core'),
                            'description' => __('Color Picker, you can set heading color.', 'theme-core'),
                        ),
                        // Heading H4
                        array(
                            'type' => 'color',
                            'name' => 'heading_h4',
                            'label' => __('Heading H4', 'theme-core'),
                            'description' => __('Color Picker, you can set heading color.', 'theme-core'),
                        ),
                        // Heading H5
                        array(
                            'type' => 'color',
                            'name' => 'heading_h5',
                            'label' => __('Heading H5', 'theme-core'),
                            'description' => __('Color Picker, you can set heading color.', 'theme-core'),
                        ),
                        // Heading H6
                        array(
                            'type' => 'color',
                            'name' => 'heading_h6',
                            'label' => __('Heading H6', 'theme-core'),
                            'description' => __('Color Picker, you can set heading color.', 'theme-core'),
                        ),
                    ),
                ),
                // Header Section
                array(
                    'type' => 'section',
                    'title' => __('Header', 'theme-core'),
                    'fields' => array(
                        // Menu Normal Color
                        array(
                            'type' => 'color',
                            'name' => 'menu_normal',
                            'label' => __('Menu Color', 'theme-core'),
                            'description' => __('Color Picker, you can set menu color.', 'theme-core'),
                        ),
                        // Menu Active & Hover Color
                        array(
                            'type' => 'color',
                            'name' => 'menu_active',
                            'label' => __('Menu Active/Hover Color', 'theme-core'),
                            'description' => __('Color Picker, you can set menu active/hover color.', 'theme-core'),
                        ),
                        // Header BG Color
                        array(
                            'type' => 'color',
                            'name' => 'header_bg',
                            'label' => __('Menu Header Background Color', 'theme-core'),
                            'description' => __('Color Picker, you can set background color.', 'theme-core'),
                        ),
                    ),
                ),
                // Body Section
                array(
                    'type' => 'section',
                    'title' => __('Body', 'theme-core'),
                    'fields' => array(
                        // Body Color
                        array(
                            'type' => 'color',
                            'name' => 'body_color',
                            'label' => __('Body Color', 'theme-core'),
                            'description' => __('Color Picker, you can set body color, general p tag.', 'theme-core'),
                        ),
                    ),
                ),
                // Footer Section
                array(
                    'type' => 'section',
                    'title' => __('Footer', 'theme-core'),
                    'fields' => array(
                        // Footer Background Color
                        array(
                            'type' => 'color',
                            'name' => 'footer_bg',
                            'label' => __('Footer Background Color', 'theme-core'),
                            'description' => __('Color Picker, you can set footer background color.', 'theme-core'),
                        ),
                        // Footer Color
                        array(
                            'type' => 'color',
                            'name' => 'footer_color',
                            'label' => __('Footer Color', 'theme-core'),
                            'description' => __('Color Picker, you can set footer color.', 'theme-core'),
                        ),
                    ),
                ),
                // Other Styling
                array(
                    'type' => 'section',
                    'title' => __('Other Styling', 'theme-core'),
                    'fields' => array(
                        // Page title Color
                        array(
                            'type' => 'color',
                            'name' => 'page_title',
                            'label' => __('Page Title Color', 'theme-core'),
                            'description' => __('Color Picker, you can set page title color.', 'theme-core'),
                        ),
                        // Single Post title Color
                        array(
                            'type' => 'color',
                            'name' => 'single_post',
                            'label' => __('Single Post Title Color', 'theme-core'),
                            'description' => __('Color Picker, you can set single post title color.', 'theme-core'),
                        ),
                        // Links Color
                        array(
                            'type' => 'color',
                            'name' => 'links_normal',
                            'label' => __('Links Color', 'theme-core'),
                            'description' => __('Color Picker, you can set links color.', 'theme-core'),
                        ),
                        // Links Color
                        array(
                            'type' => 'color',
                            'name' => 'links_hover',
                            'label' => __('Links Hover Color', 'theme-core'),
                            'description' => __('Color Picker, you can set links hover color.', 'theme-core'),
                        ),
                        // Widget Title
                        array(
                            'type' => 'color',
                            'name' => 'widget_title',
                            'label' => __('Widget Title Color', 'theme-core'),
                            'description' => __('Color Picker, you can set widget title color.', 'theme-core'),
                        ),
                    ),
                ),
            ),
        ),
        // Typography Options
        array(
            'title' => __('Typography Options', 'theme-core'),
            'name' => 'typo_options',
            'icon' => 'font-awesome:fa-text-width',
            'controls' => array(
                // Headings Section
                array(
                    'type' => 'section',
                    'title' => __('Headings Font Family', 'theme-core'),
                    'fields' => array(
                        array(
                            'type' => 'select',
                            'name' => 'headings_font_face',
                            'label' => __('Headings Font Face: h1,h2,h3', 'theme-core'),
                            'items' => array(
                                'data' => array(
                                    array(
                                        'source' => 'function',
                                        'value' => 'vp_get_gwf_family',
                                    ),
                                ),
                            ),
                            //'default' => '{{first}}'
                        ),
                        array(
                            'type' => 'radiobutton',
                            'name' => 'headings_font_weight',
                            'label' => __('Headings Font Weight', 'theme-core'),
                            'items' => array(
                                'data' => array(
                                    array(
                                        'source' => 'binding',
                                        'field' => 'headings_font_face',
                                        'value' => 'vp_get_gwf_weight',
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
                // Meta Section
                array(
                    'type' => 'section',
                    'title' => __('Meta Data Font Family', 'theme-core'),
                    'fields' => array(
                        array(
                            'type' => 'select',
                            'name' => 'meta_font_face',
                            'label' => __('Meta Data Font Face: h4,h5,h6, widget title etc.', 'theme-core'),
                            'items' => array(
                                'data' => array(
                                    array(
                                        'source' => 'function',
                                        'value' => 'vp_get_gwf_family',
                                    ),
                                ),
                            ),
                            //'default' => '{{first}}'
                        ),
                        array(
                            'type' => 'radiobutton',
                            'name' => 'meta_font_weight',
                            'label' => __('Meta Data Font Weight', 'theme-core'),
                            'items' => array(
                                'data' => array(
                                    array(
                                        'source' => 'binding',
                                        'field' => 'meta_font_face',
                                        'value' => 'vp_get_gwf_weight',
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
                // Body Section
                array(
                    'type' => 'section',
                    'title' => __('Body Font Family', 'theme-core'),
                    'fields' => array(
                        array(
                            'type' => 'select',
                            'name' => 'body_font_face',
                            'label' => __('Body Font Face', 'theme-core'),
                            'items' => array(
                                'data' => array(
                                    array(
                                        'source' => 'function',
                                        'value' => 'vp_get_gwf_family',
                                    ),
                                ),
                            ),
                            //'default' => '{{first}}'
                        ),
                        array(
                            'type' => 'radiobutton',
                            'name' => 'body_font_weight',
                            'label' => __('Body Font Weight', 'theme-core'),
                            'items' => array(
                                'data' => array(
                                    array(
                                        'source' => 'binding',
                                        'field' => 'body_font_face',
                                        'value' => 'vp_get_gwf_weight',
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
                // Font Sizes Section
                array(
                    'type' => 'section',
                    'title' => __('Font Sizes', 'theme-core'),
                    'fields' => array(
                        // Body Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'body_font_size',
                            'label'   => __('Body Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // H1 Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'h1_font_size',
                            'label'   => __('H1 Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // H2 Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'h2_font_size',
                            'label'   => __('H2 Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // H3 Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'h3_font_size',
                            'label'   => __('H3 Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // H4 Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'h4_font_size',
                            'label'   => __('H4 Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // H5 Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'h5_font_size',
                            'label'   => __('H5 Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // H6 Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'h6_font_size',
                            'label'   => __('H6 Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // Menu Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'menu_font_size',
                            'label'   => __('Menu Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // Page Title Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'page_title_font_size',
                            'label'   => __('Page Title Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // Post Title Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'post_title_font_size',
                            'label'   => __('Post Title Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                    ),
                ),
            ),
        ),
        // Single Page Options
        array(
            'title' => __('Post Page Options', 'theme-core'),
            'name' => 'post_options',
            'icon' => 'font-awesome:fa-files-o',
            'controls' => array(
                // Headings Section
                array(
                    'type' => 'section',
                    'title' => __('Single Page Details', 'theme-core'),
                    'fields' => array(
                        // Hide Category
                        array(
                            'type' => 'toggle',
                            'name' => 'hide_category',
                            'label' => __('Hide Category', 'theme-core'),
                            'description' => __('You can hide the category title.', 'theme-core'),
                            'default' => '0',
                        ),
                        // Hide Date
                        array(
                            'type' => 'toggle',
                            'name' => 'hide_date',
                            'label' => __('Hide Date', 'theme-core'),
                            'description' => __('You can hide banner date.', 'theme-core'),
                            'default' => '0',
                        ),
                        // Hide Author
                        array(
                            'type' => 'toggle',
                            'name' => 'hide_author',
                            'label' => __('Hide Author Title', 'theme-core'),
                            'description' => __('You can hide the author title.', 'theme-core'),
                            'default' => '0',
                        ),
                        // Hide Social Share
                        array(
                            'type' => 'toggle',
                            'name' => 'hide_social',
                            'label' => __('Hide Social Share', 'theme-core'),
                            'description' => __('You can hide social share for post.', 'theme-core'),
                            'default' => '0',
                        ),
                    ),
                ),
            ),
        ),
        // 404 Page Options
        array(
            'title' => __('404 Page Options', 'theme-core'),
            'name' => 'page404_options',
            'icon' => 'font-awesome:fa-warning',
            'controls' => array(
                // Headings Section
                array(
                    'type' => 'section',
                    'title' => __('404 Page Details', 'theme-core'),
                    'fields' => array(
                        // 404 Editor
                        array(
                            'type' => 'codeeditor',
                            'name' => 'error_404',
                            'label' => __('Page Text', 'theme-core'),
                            'description' => __('HTML tags are supported.', 'theme-core'),
                            'theme' => 'github',
                            'mode' => 'html',
                        ),
                    ),
                ),
            ),
        ),
        // Pages Footer
        array(
            'title' => __('Footer Options', 'theme-core'),
            'name' => 'contact_options',
            'icon' => 'font-awesome:fa-flag',
            'controls' => array(
                // Social Connect
                array(
                    'type' => 'section',
                    'title' => __('Social Connect', 'theme-core'),
                    'fields' => array(
                        // Facebook
                        array(
                            'type' => 'textbox',
                            'name' => 'facebook',
                            'label' => __('Facebook', 'theme-core'),
                            'description' => __('Leave empty if not required.', 'theme-core'),
                            'default' => '#',
                        ),
                        // Twitter
                        array(
                            'type' => 'textbox',
                            'name' => 'twitter',
                            'label' => __('Twitter', 'theme-core'),
                            'description' => __('Leave empty if not required.', 'theme-core'),
                            'default' => '#',
                        ),
                        // Dribble
                        array(
                            'type' => 'textbox',
                            'name' => 'dribbble',
                            'label' => __('Dribbble', 'theme-core'),
                            'description' => __('Leave empty if not required.', 'theme-core'),
                            'default' => '',
                        ),
                        // Google Plus
                        array(
                            'type' => 'textbox',
                            'name' => 'google',
                            'label' => __('Google+', 'theme-core'),
                            'description' => __('Leave empty if not required.', 'theme-core'),
                            'default' => '#',
                        ),
                        // Linkedin
                        array(
                            'type' => 'textbox',
                            'name' => 'linkedin',
                            'label' => __('LinkedIn', 'theme-core'),
                            'description' => __('Leave empty if not required.', 'theme-core'),
                            'default' => '',
                        ),
                        // Pinterest
                        array(
                            'type' => 'textbox',
                            'name' => 'pinterest',
                            'label' => __('Pinterest', 'theme-core'),
                            'description' => __('Leave empty if not required.', 'theme-core'),
                            'default' => '#',
                        ),
                        // Behance
                        array(
                            'type' => 'textbox',
                            'name' => 'behance',
                            'label' => __('Behance', 'theme-core'),
                            'description' => __('Leave empty if not required.', 'theme-core'),
                            'default' => '',
                        ),
                        // Instagram
                        array(
                            'type' => 'textbox',
                            'name' => 'instagram',
                            'label' => __('Instagram', 'theme-core'),
                            'description' => __('Leave empty if not required.', 'theme-core'),
                            'default' => '',
                        ),
                    ),
                ),
            ),
        ),
    )
);
/**
 *EOF
 */