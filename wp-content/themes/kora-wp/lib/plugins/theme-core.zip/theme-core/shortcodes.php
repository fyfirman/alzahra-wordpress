<?php
// Content filter used ONLY on custom theme shortcodes to remove
add_filter("the_content", "the_content_filter");
function the_content_filter($content) {
    // array of custom shortcodes requiring the fix
    $block = join("|",array(
        "pricing_table",
    ));
// opening tag
    $rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
// closing tag
    $rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
    return $rep;
}
// Container Shortcode
function container_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['class'])){
        $class = $atts['class'];
    } else {
        $class = '';
    }
    $out = '';
    $out .= '<div class="container '.$class.'">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
add_shortcode('container', 'container_shortcode');
// Services Box
function services_box_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['txt_desc'])){
        $txt_desc = $atts['txt_desc'];
    } else {
        $txt_desc = '';
    }
    if(!empty($atts['icon'])){
        $icon = $atts['icon'];
    } else {
        $icon = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }
    $out = '';
    $out .= '<div class="services w-100 animate '.$animations.'" data-wow-delay="'.$delay.'s">';
    $out .= '<div class="sec '.$style.'"> <i class="'.$icon.'"></i>';
    $out .= '<h6>'.$heading.'</h6>';
    $out .= '<div class="ser-over">';
    $out .= '<h6>'.$heading.'</h6>';
    $out .= '<p>'.$txt_desc.'</p>';
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('services_box', 'services_box_shortcode');
// Counter Box
function counter_box_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['icon'])){
        $icon = $atts['icon'];
    } else {
        $icon = '';
    }
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    $out = '<div id="counters">';
    $out .= '<div class="w-100 animate '.$animations.'" data-wow-delay="'.$delay.'s"><i class="'.$icon.'"></i>';
    $out .= '<hr>';
    $out .= '<span class="detect">'.$number.'</span>';
    $out .= '<h6>'.$heading.'</h6>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('counter_box', 'counter_box_shortcode');
// Testimonials Shortcode
function testimonials_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 3;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    if(!empty($atts['grp_slug'])){
        $grp_slug = $atts['grp_slug'];
        $args = array(
            'post_type' => 'kora-testimonials',
            'posts_per_page' => $number,
            'order' => $order,
            'tax_query' => array(
                array(
                    'taxonomy' => 'kora_testimonials_genre',
                    'field'    => 'slug',
                    'terms'    => $grp_slug,
                ),
            ),
        );
    } else {
        $args = array(
            'post_type' => 'kora-testimonials',
            'posts_per_page' => $number,
            'order' => $order
        );
    }
    $out = '';
    $out .= '<div class="testimonials">';
    $out .= '<div class="single-slides margin-top-50 margin-bottom-80">';
    $testimonials_query = new WP_Query($args);
    while($testimonials_query->have_posts()): $testimonials_query->the_post();
        $client_name = kora_get_field('client_name');
        $client_designation = kora_get_field('client_designation');
        $out .= '<div class="item">';
        $out .= '<p>'.do_shortcode(get_the_content()).'</p>';
        $out .= '<span>'.$client_name.', '.$client_designation.'</span>';
        $out .= '</div>';
    endwhile;
    wp_reset_query();
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('testimonials', 'testimonials_shortcode');
// Simple Heading Shortcode
function simple_heading_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['txt'])){
        $txt = $atts['txt'];
    } else {
        $txt = '';
    }
    if(!empty($atts['heading_style'])){
        $heading_style = $atts['heading_style'];
    } else {
        $heading_style = 'h2';
    }
    $out = '';
    $out .= '<'.$heading_style.' class="simple-tittle margin-bottom-50">'.$txt.'</'.$heading_style.'>';
    return $out;
}
add_shortcode('simple_heading', 'simple_heading_shortcode');
// Pricing Table Shortcode
function pricing_table_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['pkg_title'])){
        $pkg_title = $atts['pkg_title'];
    } else {
        $pkg_title = '';
    }
    if(!empty($atts['pkg_price'])){
        $pkg_price = $atts['pkg_price'];
    } else {
        $pkg_price = '';
    }
    if(!empty($atts['btn_txt'])){
        $btn_txt = $atts['btn_txt'];
    } else {
        $btn_txt = '';
    }
    if(!empty($atts['btn_link'])){
        $btn_link = $atts['btn_link'];
    } else {
        $btn_link = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }
    $out = '';
    $out .= '<div class="pricing animate '.$animations.'" data-wow-delay="'.$delay.'s">';
    $out .= '<div class="price-in '.$style.'">';
    $out .= '<div class="price-head">';
    $out .= '<h6>'.$pkg_title.'</h6>';
    $out .= '<h3>'.$pkg_price.'</h3>';
    $out .= '</div>';
    $out .= '<div class="clear clearfix"></div>';
    $out .= do_shortcode($content);
    $out .= '<div class="clear clearfix"></div>';
    if(!empty($btn_txt)){
        $out .= '<a href="'.$btn_link.'" class="btn">'.$btn_txt.'</a>';
    }
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('pricing_table', 'pricing_table_shortcode');
// Simple Image Shortcode
function simple_img_slides_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div  class="single-slides no-controls">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
add_shortcode('simple_img_slides', 'simple_img_slides_shortcode');
add_shortcode('simple_img_slide', 'simple_img_slide_shortcode');
function simple_img_slide_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img src="'.$image_info[0].'" alt="">';
    } else {
        $image = '';
    }
    $out = '';
    $out .= '<div class="item">';
    $out .= $image;
    $out .= '</div>';
    return $out;
}
// Social Links Shortcode
function social_links_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['facebook'])){
        $facebook = $atts['facebook'];
    } else {
        $facebook = '';
    }
    if(!empty($atts['twitter'])){
        $twitter = $atts['twitter'];
    } else {
        $twitter = '';
    }
    if(!empty($atts['linkedin'])){
        $linkedin = $atts['linkedin'];
    } else {
        $linkedin = '';
    }
    if(!empty($atts['behance'])){
        $behance = $atts['behance'];
    } else {
        $behance = '';
    }
    if(!empty($atts['google_plus'])){
        $google_plus = $atts['google_plus'];
    } else {
        $google_plus = '';
    }
    if(!empty($atts['pinterest'])){
        $pinterest = $atts['pinterest'];
    } else {
        $pinterest = '';
    }
    if(!empty($atts['instagram'])){
        $instagram = $atts['instagram'];
    } else {
        $instagram = '';
    }
    $out = '';
    $out .= '<ul class="social-link">';
    if(!empty($facebook)){
        $out .= '<li><a href="'.$facebook.'">Facebook</a></li>';
    } if(!empty($twitter)){
        $out .= '<li><a href="'.$twitter.'">Twitter</a></li>';
    } if(!empty($behance)){
        $out .= '<li><a href="'.$behance.'">Behance</a></li>';
    } if(!empty($google_plus)){
        $out .= '<li><a href="'.$google_plus.'">Google+</a></li>';
    } if(!empty($linkedin)){
        $out .= '<li><a href="'.$linkedin.'">Linkedin</a></li>';
    } if(!empty($pinterest)){
        $out .= '<li><a href="'.$pinterest.'">Pinterest</a></li>';
    } if(!empty($instagram)){
        $out .= '<li><a href="'.$instagram.'">Instagram</a></li>';
    }
    $out .= '</ul>';
    return $out;
}
add_shortcode('social_links', 'social_links_shortcode');
// Image With Column Shortcode
function img_with_column_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img src="'.$image_info[0].'" alt="">';
    } else {
        $image = '';
    }
    if(!empty($atts['caption'])){
        $caption = '<h6 class="text-center font-bold margin-top-20">'.$atts['caption'].'</h6>';
    } else {
        $caption = '';
    }
    if(!empty($atts['column'])){
        $column = $atts['column'];
    } else {
        $column = '6';
    }
    if(!empty($atts['padding_left'])){
        $padding_left = 'padding-left: '.$atts['padding_left'].'px;';
    } else {
        $padding_left = '';
    }
    if(!empty($atts['padding_right'])){
        $padding_right = 'padding-right: '.$atts['padding_right'].'px;';
    } else {
        $padding_right = '';
    }
    $out = '';
    $out .= '<div class="col-sm-'.$column.'" style="'.$padding_left.' '.$padding_right.'">';
    $out .= $image;
    $out .= $caption;
    $out .= '</div>';
    return $out;
}
add_shortcode('img_with_column', 'img_with_column_shortcode');
// Contact Info Shortcode
function contact_info_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['address'])){
        $address = $atts['address'];
    } else {
        $address = '';
    }
    if(!empty($atts['phone'])){
        $phone = $atts['phone'];
    } else {
        $phone = '';
    }
    if(!empty($atts['email'])){
        $email = $atts['email'];
    } else {
        $email = '';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    $out = '';
    $out .= '<div class="contact-info animate '.$animations.'" data-wow-delay="'.$delay.'s">';
    $out .= '<h6 class="margin-top-30 margin-bottom-20 font-bold">'.$heading.'</h6>';
    $out .= '<ul class="row font-roboto">';
    $out .= '<li class="col-md-5">'.$address.'</li>';
    $out .= '<li class="col-md-5"> '.$phone.'<br>';
    $out .= $email;
    $out .= '</li>';
    $out .= '</ul>';
    $out .= '</div>';
    return $out;
}
add_shortcode('contact_info', 'contact_info_shortcode');
// Title Block Shortcode
function title_block_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['small_desc'])){
        $small_desc = $atts['small_desc'];
    } else {
        $small_desc = '';
    }
    if(!empty($atts['heading_style'])){
        $heading_style = $atts['heading_style'];
    } else {
        $heading_style = 'h2';
    }
    $out = '';
    $out .= '<div class="tittle-block margin-bottom-40">';
    $out .= '<'.$heading_style.' class="margin-bottom-30">'.$heading.'</'.$heading_style.'>';
    $out .= '<p>'.$small_desc.'</p>';
    $out .= '</div>';
    return $out;
}
add_shortcode('title_block', 'title_block_shortcode');
// Text Services Shortcode
function text_services_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['txt_desc'])){
        $txt_desc = $atts['txt_desc'];
    } else {
        $txt_desc = '';
    }
    if(!empty($atts['column'])){
        $column = $atts['column'];
    } else {
        $column = '6';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    $out = '';
    $out .= '<div class="col-sm-'.$column.' txt-services margin-bottom-50 animate '.$animations.'" data-wow-delay="'.$delay.'s">';
    $out .= '<h6>'.$heading.'</h6>';
    $out .= '<p>'.$txt_desc.'</p>';
    $out .= '</div>';
    return $out;
}
add_shortcode('text_services', 'text_services_shortcode');
// Portfolio Shortcode
function portfolio_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['layout'])){
        $layout = $atts['layout'];
    } else {
        $layout = '';
    }
    if(!empty($atts['columns'])){
        $columns = $atts['columns'];
    } else {
        $columns = 'col-3';
    }
    if(!empty($atts['hide_filters'])){
        $hide_filters = $atts['hide_filters'];
    } else {
        $hide_filters = 'no';
    }
    if(!empty($atts['portfolio_categories'])){
        $portfolio_categories = $atts['portfolio_categories'];
    } else {
        $portfolio_categories = '';
    }
    if(!empty($atts['number_of_posts'])){
        $number_of_posts = $atts['number_of_posts'];
    } else {
        $number_of_posts = 6;
    }
    if(!empty($atts['load_more_page'])){
        $load_more_page = $atts['load_more_page'];
    } else {
        $load_more_page = '';
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    if(!empty($atts['load_more_txt'])){
        $load_more_txt = $atts['load_more_txt'];
    } else {
        $load_more_txt = '';
    }
    if(!empty($atts['loading_txt'])){
        $loading_txt = $atts['loading_txt'];
    } else {
        $loading_txt = '';
    }
    if(!empty($atts['no_work_txt'])){
        $no_work_txt = $atts['no_work_txt'];
    } else {
        $no_work_txt = '';
    }
    $out = '';

    if(!empty($portfolio_categories)){
        $ex_portfolio_categories = explode(",",$portfolio_categories);
        $categories = get_terms( 'kora_genre', array(
            'orderby'    => 'count',
            'hide_empty' => 1,
            'include'    => $ex_portfolio_categories
        ) );
        // For Load More Page
        $sp_cats = $portfolio_categories;
    }else{
        $sp_cats = 'no_cat';
        $categories = get_terms( 'kora_genre', array(
            'orderby'    => 'count',
            'hide_empty' => 1
        ) );
    }
    // Loop Arguments
    $term_array = array();
    foreach($categories as $cat) {
        $term_array[] = $cat->slug;
    }
    $portfolio = array(
        'post_type' => 'kora_portfolio',
        'posts_per_page' => $number_of_posts,
        'order' => $order,
        'tax_query' => array(
            array(
                'taxonomy' => 'kora_genre',
                'field'    => 'slug',
                'terms'    => $term_array,
            ),
        ),
    );
    $portfolio_loop = new WP_Query($portfolio);
    // Layout 1
    if($layout == 'pl1'){
        $out .= '<div class="portfolio">';
        $out .= '<div id="js-grid-awesome-work" class="'.$columns.'">';
        while ( $portfolio_loop->have_posts() ) : $portfolio_loop->the_post();
            $terms = get_the_terms(get_the_ID(), 'kora_genre');
            $out .= '<!-- PORTOFLIO ITEM -->';
            $out .= '<div class="cbp-item">';
            if(has_post_thumbnail()){
                $out .= '<img src="'.get_feature_image_url(get_the_ID()).'" alt="">';
            } else {
                $out .= '<img src="https://placeholdit.imgix.net/~text?txtsize=28&txt=No+Image&w=370&h=370" alt="">';
            }
            $out .= '<div class="hover-port">';
            $out .= '<div class="hover-in">';
            $out .= '<div class="position-center-center full-width">';
            $out .= '<h6>'.get_the_title().'</h6>';
            $out .= '<span>';
            $term_counter = 0;
            $len = count($terms);
            foreach ($terms as $ter){
                if ($term_counter == $len - 1) {
                    $out .= esc_attr($ter->name);
                } else {
                    $out .= esc_attr($ter->name). ' , ';
                }
                $term_counter++;
            }
            $out .= '</span>';
            $single_portfolio_page_layout = kora_get_field('single_portfolio_page_layout');
            if($single_portfolio_page_layout == 'popup-detailed' || $single_portfolio_page_layout == 'popup-side-info'|| $single_portfolio_page_layout == 'popup-case-details'){
                $single = 'cbp-singlePage';
            } else {
                $single = 'singlePage';
            }
            $out .= '<a href="'.get_permalink().'" class="'.$single.'" rel="nofollow"><i class="fa fa-link"></i></a>';
            $out .= '<a href="'.get_feature_image_url(get_the_ID()).'" class="cbp-lightbox" data-title=""><i class="ion-ios-search-strong"></i></a>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '<!-- End Portfolio  Layout -->';
        endwhile;
        wp_reset_query();
        $out .= '</div>';
        if(!empty($load_more_txt)){
            $out .= '<!-- LOAD MORE -->';
            $out .= '<div id="js-loadMore-awesome-work" class="text-center">';
            $out .= '<a href="'.esc_url(home_url('/')).'?page_id='.$load_more_page.'&number_of_posts='.$number_of_posts.'&pl=normal-4-column-full&select_portfolio_categories='.$sp_cats.'" class="cbp-l-loadMore-link btn text-center" rel="nofollow">';
            $out .= '<span class="cbp-l-loadMore-defaultText">'.$load_more_txt.'</span>';
            $out .= '<span class="cbp-l-loadMore-loadingText">'.$loading_txt.'</span>';
            $out .= '<span class="cbp-l-loadMore-noMoreLoading">'.$no_work_txt.'</span>';
            $out .= '</a>';
            $out .= '</div>';
        }
        $out .= '</div>';
    } elseif($layout == 'pl2'){
        $out .= '<div class="portfolio">';
        if($hide_filters != 'yes'){
            $out .= '<!-- PORTOFLIO ITEMS  FILTER -->';
            $out .= '<div id="js-filters-awesome-work" class="cbp-l-filters-buttonCenter">';
            $out .= '<div data-filter="*" class="cbp-filter-item-active cbp-filter-item">';
            $out .= esc_html__('All','kora-wp');
            $out .= '<div class="cbp-filter-counter"></div>';
            $out .= '</div>';
            foreach($categories as $cats){
                $out .= '<div data-filter=".'.esc_attr($cats->slug).'" class="cbp-filter-item">';
                $out .= esc_attr($cats->name);
                $out .= '<div class="cbp-filter-counter"></div>';
                $out .= '</div>';
            }
            $out .= '</div>';
        }
        $out .= '<div id="js-grid-awesome-work" class="'.$columns.' with-space">';
        while ( $portfolio_loop->have_posts() ) : $portfolio_loop->the_post();
            $terms = get_the_terms(get_the_ID(), 'kora_genre');
            $classes = '';
            if($hide_filters != 'yes'){
                foreach ($terms as $ter){
                    $classes .= esc_attr($ter->slug). ' ';
                }
            }
            $out .= '<!-- PORTOFLIO ITEM -->';
            $out .= '<div class="cbp-item '.$classes.'">';
            if(has_post_thumbnail()){
                $out .= '<img src="'.get_feature_image_url(get_the_ID()).'" alt="">';
            } else {
                $out .= '<img src="https://placeholdit.imgix.net/~text?txtsize=28&txt=No+Image&w=370&h=370" alt="">';
            }
            $out .= '<div class="hover-port">';
            $out .= '<div class="hover-in">';
            $out .= '<div class="position-center-center full-width">';
            $out .= '<h6>'.get_the_title().'</h6>';
            $out .= '<span>';
            $term_counter = 0;
            $len = count($terms);
            foreach ($terms as $ter){
                if ($term_counter == $len - 1) {
                    $out .= esc_attr($ter->name);
                } else {
                    $out .= esc_attr($ter->name). ' , ';
                }
                $term_counter++;
            }
            $out .= '</span>';
            $single_portfolio_page_layout = kora_get_field('single_portfolio_page_layout');
            if($single_portfolio_page_layout == 'popup-detailed' || $single_portfolio_page_layout == 'popup-side-info'|| $single_portfolio_page_layout == 'popup-case-details'){
                $single = 'cbp-singlePage';
            } else {
                $single = 'singlePage';
            }
            $out .= '<a href="'.get_permalink().'" class="'.$single.'" rel="nofollow"><i class="fa fa-link"></i></a>';
            $out .= '<a href="'.get_feature_image_url(get_the_ID()).'" class="cbp-lightbox" data-title=""><i class="ion-ios-search-strong"></i></a>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '<!-- End Portfolio  Layout -->';
        endwhile;
        wp_reset_query();
        $out .= '</div>';
        if(!empty($load_more_txt)){
            $out .= '<!-- LOAD MORE -->';
            $out .= '<div id="js-loadMore-awesome-work" class="text-center">';
            $out .= '<a href="'.esc_url(home_url('/')).'?page_id='.$load_more_page.'&number_of_posts='.$number_of_posts.'&pl=normal-4-column-full&select_portfolio_categories='.$sp_cats.'" class="cbp-l-loadMore-link btn text-center" rel="nofollow">';
            $out .= '<span class="cbp-l-loadMore-defaultText">'.$load_more_txt.'</span>';
            $out .= '<span class="cbp-l-loadMore-loadingText">'.$loading_txt.'</span>';
            $out .= '<span class="cbp-l-loadMore-noMoreLoading">'.$no_work_txt.'</span>';
            $out .= '</a>';
            $out .= '</div>';
        }
        $out .= '</div>';
    } else{
        $out .= '<div class="port-style-6">';
        if($hide_filters != 'yes'){
            $out .= '<div class="row">';
            $out .= '<div class="col-md-10">';
            $out .= '<!-- PORTOFLIO ITEMS FILTER -->';
            $out .= '<div class="filter-large">';
            $out .= '<!-- PORTOFLIO ITEMS  FILTER -->';
            $out .= '<div id="js-filters-awesome-work" class="cbp-l-filters-buttonCenter">';
            $out .= '<div data-filter="*" class="cbp-filter-item-active cbp-filter-item">';
            $out .= esc_html__('All','kora-wp');
            $out .= '<div class="cbp-filter-counter"></div>';
            $out .= '</div>';
            foreach($categories as $cats){
                $out .= '<div data-filter=".'.esc_attr($cats->slug).'" class="cbp-filter-item">';
                $out .= esc_attr($cats->name);
                $out .= '<div class="cbp-filter-counter"></div>';
                $out .= '</div>';
            }
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</div>';
        }
        $out .= '<div class="portfolio padding-top-100 padding-bottom-100">';
        $out .= '<div id="js-grid-awesome-work" class="'.$columns.' with-space">';
        while ( $portfolio_loop->have_posts() ) : $portfolio_loop->the_post();
            $terms = get_the_terms(get_the_ID(), 'kora_genre');
            $classes = '';
            if($hide_filters != 'yes'){
                foreach ($terms as $ter){
                    $classes .= esc_attr($ter->slug). ' ';
                }
            }
            $out .= '<!-- PORTOFLIO ITEM -->';
            $out .= '<div class="cbp-item '.$classes.'">';
            if(has_post_thumbnail()){
                $out .= '<img src="'.get_feature_image_url(get_the_ID()).'" alt="">';
            } else {
                $out .= '<img src="https://placeholdit.imgix.net/~text?txtsize=28&txt=No+Image&w=370&h=370" alt="">';
            }
            $out .= '<div class="hover-port">';
            $out .= '<div class="hover-in">';
            $out .= '<div class="position-center-center full-width">';
            $out .= '<h6>'.get_the_title().'</h6>';
            $out .= '<span>';
            $term_counter = 0;
            $len = count($terms);
            foreach ($terms as $ter){
                if ($term_counter == $len - 1) {
                    $out .= esc_attr($ter->name);
                } else {
                    $out .= esc_attr($ter->name). ' , ';
                }
                $term_counter++;
            }
            $out .= '</span>';
            $single_portfolio_page_layout = kora_get_field('single_portfolio_page_layout');
            if($single_portfolio_page_layout == 'popup-detailed' || $single_portfolio_page_layout == 'popup-side-info'|| $single_portfolio_page_layout == 'popup-case-details'){
                $single = 'cbp-singlePage';
            } else {
                $single = 'singlePage';
            }
            $out .= '<a href="'.get_permalink().'" class="'.$single.'" rel="nofollow"><i class="fa fa-link"></i></a>';
            $out .= '<a href="'.get_feature_image_url(get_the_ID()).'" class="cbp-lightbox" data-title=""><i class="ion-ios-search-strong"></i></a>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '</div>';
            $out .= '<!-- End Portfolio  Layout -->';
        endwhile;
        wp_reset_query();
        $out .= '</div>';
        $out .= '</div>';
        if(!empty($load_more_txt)){
            $out .= '<!-- LOAD MORE -->';
            $out .= '<div id="js-loadMore-awesome-work" class="text-center">';
            $out .= '<a href="'.esc_url(home_url('/')).'?page_id='.$load_more_page.'&number_of_posts='.$number_of_posts.'&pl=normal-4-column-full&select_portfolio_categories='.$sp_cats.'" class="cbp-l-loadMore-link btn text-center" rel="nofollow">';
            $out .= '<span class="cbp-l-loadMore-defaultText">'.$load_more_txt.'</span>';
            $out .= '<span class="cbp-l-loadMore-loadingText">'.$loading_txt.'</span>';
            $out .= '<span class="cbp-l-loadMore-noMoreLoading">'.$no_work_txt.'</span>';
            $out .= '</a>';
            $out .= '</div>';
        }
        $out .= '</div>';
    }

    return $out;
}
add_shortcode('portfolio', 'portfolio_shortcode');
// Blog Posts Shortcode
function blog_posts_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 3;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    if(!empty($atts['cat_slug'])){
        $cat_slug = $atts['cat_slug'];
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $number,
            'order' => $order,
            'category_name' => $cat_slug
        );
    } else {
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $number,
            'order' => $order
        );
    }
    $out = '';
    $blog_query = new WP_Query($args);
    $out .= '<div class="blog-news">';
    $count = 1;
    while($blog_query->have_posts()): $blog_query->the_post();
        $post_animations_type = kora_get_field('post_animations_type');
        $post_animation_duration = kora_get_field('post_animation_duration');
        if(has_post_thumbnail()){
            $class = 'col-md-6';
        } else {
            $class = 'col-md-12';
        }
        if($count % 2 == 0){
            $out .= '<ul class="row margin-top-50">';
            $out .= '<!-- Blog Img -->';
            if(has_post_thumbnail()){
                $out .= '<li class="col-md-6">';
                $out .= '<img class="img-responsive" src="'.get_feature_image_url(get_the_ID()).'" alt="" >';
                $out .= '</li>';
            }
            $out .= '<!-- Blog Text -->';
            $out .= '<li class="'.$class.' text-right animate '.$post_animations_type.'" data-wow-delay="'.$post_animation_duration.'s">';
            $out .= '<a href="'.get_the_permalink().'" class="post-tittle">'.get_the_title().'</a>';
            $out .= '<p>'.kora_shortcode_excerpt(150).'..</p>';
            $out .= '<ul class="social-link">';
            $out .= '<li class="no-margin padding-left-30"><a href="'.get_the_permalink().'">'.esc_html__('Continue Reading','kora-wp').'</a></li>';
            $out .= '<li class="no-margin padding-left-30"><a href="http://www.facebook.com/sharer.php?u='.get_the_permalink().'&amp;t='.get_the_title().'">'.esc_html__('Share','kora-wp').'</a></li>';
            $out .= '</ul>';
            $out .= '</li>';
            $out .= '</ul>';
        } else{
            $out .= '<ul class="row">';
            $out .= '<li class="'.$class.' animate '.$post_animations_type.'" data-wow-delay="'.$post_animation_duration.'s">';
            $out .= '<a href="'.get_the_permalink().'" class="post-tittle">'.get_the_title().'</a>';
            $out .= '<p>'.kora_shortcode_excerpt(150).'..</p>';
            $out .= '<ul class="social-link">';
            $out .= '<li><a href="'.get_the_permalink().'">'.esc_html__('Continue Reading','kora-wp').'</a></li>';
            $out .= '<li><a href="http://www.facebook.com/sharer.php?u='.get_the_permalink().'&amp;t='.get_the_title().'">'.esc_html__('Share','kora-wp').'</a></li>';
            $out .= '</ul>';
            $out .= '</li>';
            if(has_post_thumbnail()){
                $out .= '<li class="col-md-6">';
                $out .= '<img class="img-responsive" src="'.get_feature_image_url(get_the_ID()).'" alt="" >';
                $out .= '</li>';
            }
            $out .= '</ul>';
        }
        $count++;
    endwhile;
    wp_reset_query();
    $out .= '</div>';
    return $out;
}
add_shortcode('blog_posts', 'blog_posts_shortcode');
// Time Line Shortcode
function time_lines_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div class="education">';
    $out .= '<div class="time-line">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('time_lines', 'time_lines_shortcode');
function time_line_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['duration'])){
        $duration = $atts['duration'];
    } else {
        $duration = '';
    }
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['small_desc'])){
        $small_desc = $atts['small_desc'];
    } else {
        $small_desc = '';
    }
    if(!empty($atts['position'])){
        $position = $atts['position'];
    } else {
        $position = 'pull-right';
    }
    if(!empty($atts['animations'])){
        $animations = $atts['animations'];
    } else {
        $animations = '';
    }
    if(!empty($atts['delay'])){
        $delay = $atts['delay'];
    } else {
        $delay = '';
    }
    $out = '';
    if($position == 'pull-right'){
        $out .= '<!-- Right Timeline -->';
        $out .= '<ul class="row">';
        $out .= '<li class="col-sm-6 pull-right text-left padding-left-50 margin-bottom-30 animate '.$animations.'" data-wow-delay="'.$delay.'s">';
        $out .= '<span class="years"> '.$duration.' </span>';
        $out .= '<h6>'.$heading.'</h6>';
        $out .= '<p>'.$small_desc.'</p>';
        $out .= '</li>';
        $out .= '</ul>';
        $out .= '<div class="clearfix"></div>';
    } else {
        $out .= '<!-- Left Timeline -->';
        $out .= '<ul class="row">';
        $out .= '<li class="col-sm-6 pull-left text-right padding-right-50 animate '.$animations.'" data-wow-delay="'.$delay.'s">';
        $out .= '<span class="years"> '.$duration.' </span>';
        $out .= '<h6>'.$heading.'</h6>';
        $out .= '<p>'.$small_desc.'</p>';
        $out .= '</li>';
        $out .= '</ul>';
        $out .= '<div class="clearfix"></div>';
    }
    return $out;
}
add_shortcode('time_line', 'time_line_shortcode');
// Text Widget Shortcode Readable
add_filter( 'widget_text', 'shortcode_unautop');
add_filter( 'widget_text', 'do_shortcode');